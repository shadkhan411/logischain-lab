"""LogisChain AI - Predictive Trade Finance & Logistics Valuation."""
__version__ = "1.0.0"
