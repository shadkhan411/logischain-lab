"""
Temporal feature engineering (Section A5.2).

Builds the per-time-step feature tensor for the TCN demand/throughput
forecasting model: rolling statistics, EWMA, calendar encodings, lag
features, and Fourier terms for annual seasonality.
"""
from __future__ import annotations
import numpy as np
import pandas as pd


def build_temporal_features(series_df: pd.DataFrame, value_col: str, date_col: str = "date") -> pd.DataFrame:
    """
    series_df: single-entity (e.g. single port) time series, sorted by date.
    Returns a DataFrame of engineered features aligned to the same index.
    """
    df = series_df.sort_values(date_col).reset_index(drop=True).copy()
    v = df[value_col]

    for w in (7, 14, 30, 90):
        df[f"roll_mean_{w}"] = v.rolling(w, min_periods=1).mean()
        df[f"roll_std_{w}"] = v.rolling(w, min_periods=1).std().fillna(0)
    for w in (7, 30):
        df[f"roll_min_{w}"] = v.rolling(w, min_periods=1).min()
        df[f"roll_max_{w}"] = v.rolling(w, min_periods=1).max()
    for span in (7, 14, 30):
        df[f"ewma_{span}"] = v.ewm(span=span, adjust=False).mean()

    dow = df[date_col].dt.dayofweek
    for d in range(7):
        df[f"dow_{d}"] = (dow == d).astype(int)

    month = df[date_col].dt.month
    df["month_sin"] = np.sin(2 * np.pi * month / 12)
    df["month_cos"] = np.cos(2 * np.pi * month / 12)

    doy = df[date_col].dt.dayofyear
    df["cny_effect"] = ((doy > 20) & (doy < 60)).astype(int)  # approx CNY window
    df["golden_week_effect"] = ((month == 10) & (df[date_col].dt.day <= 7)).astype(int)

    df["yoy_pct_change"] = v.pct_change(365).fillna(0)
    for lag in (1, 7, 14, 30):
        df[f"lag_{lag}"] = v.shift(lag).bfill()

    t = np.arange(len(df))
    for period in (365.25, 182.625, 91.3125):
        df[f"fourier_sin_{int(period)}"] = np.sin(2 * np.pi * t / period)
        df[f"fourier_cos_{int(period)}"] = np.cos(2 * np.pi * t / period)

    return df


def build_multivariate_tensor(ts_df: pd.DataFrame, entity_col: str, value_col: str,
                               exog_cols: list[str] | None = None) -> dict[str, pd.DataFrame]:
    """Build per-entity feature frames, ready to stack into a TCN input tensor of shape
    (n_entities, n_timesteps, n_features)."""
    out = {}
    exog_cols = exog_cols or []
    for entity, g in ts_df.groupby(entity_col):
        feats = build_temporal_features(g, value_col=value_col)
        for c in exog_cols:
            if c not in feats.columns and c in g.columns:
                feats[c] = g[c].values
        out[entity] = feats
    return out


if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
    from src.data.synthetic_generator import SupplyChainDataGenerator

    gen = SupplyChainDataGenerator()
    ts = gen.generate_time_series(n_days=200)
    port0 = ts[ts.port == ts.port.iloc[0]]
    feats = build_temporal_features(port0, value_col="throughput_teu")
    print(feats.shape)
    print([c for c in feats.columns if c not in port0.columns][:10], "...")
