"""
Trade-finance transaction features (Section A5.3) and cross-domain fusion
features (Section A5.4): Supply-Chain-Adjusted PD (SC-PD), Working Capital
Velocity Index (WCVI), and Trade Route Financial Stress Index (TRFSI).

These are implemented exactly as the closed-form formulas documented in the
brief so results are auditable line-by-line against Section A5.4.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

LC_TRANSACTION_FEATURE_COLUMNS = [
    "lc_amount_log", "tenor_days", "commodity_risk_num", "trade_route_risk_score",
    "applicant_leverage", "applicant_current_ratio", "beneficiary_otif_rate",
    "historical_discrepancy_rate_applicant", "historical_discrepancy_rate_beneficiary",
    "port_congestion_origin", "port_congestion_destination", "freight_rate_percentile",
    "seasonal_factor", "country_risk_differential", "currency_volatility_30d",
]

_COMMODITY_RISK_MAP = {"Low": 0, "Medium": 1, "High": 2}


def build_lc_transaction_features(lc_df: pd.DataFrame) -> pd.DataFrame:
    df = lc_df.copy()
    df["lc_amount_log"] = np.log(df["lc_amount_usd"].clip(lower=1))
    df["commodity_risk_num"] = df["commodity_risk_category"].map(_COMMODITY_RISK_MAP)
    return df


def supply_chain_adjusted_pd(
    traditional_pd: float | np.ndarray,
    otif_actual: float | np.ndarray,
    inv_turnover_actual: float | np.ndarray,
    alternative_supplier_count: float | np.ndarray,
    otif_target: float = 0.90,
    inv_turnover_target: float = 6.0,
) -> np.ndarray:
    """Fusion Feature 1 - SC-PD (Section A5.4).

    SC-PD = PD_trad * (1 + 0.3*OTIF_adj + 0.2*Inv_adj + 0.15*Network_adj)
    """
    traditional_pd = np.asarray(traditional_pd, dtype=float)
    otif_actual = np.asarray(otif_actual, dtype=float)
    inv_turnover_actual = np.asarray(inv_turnover_actual, dtype=float)
    alternative_supplier_count = np.asarray(alternative_supplier_count, dtype=float)

    otif_adj = np.maximum(0, (otif_target - otif_actual) / 0.10)
    inv_adj = np.maximum(0, (inv_turnover_target - inv_turnover_actual) / 3.0)
    network_adj = 1.0 - np.minimum(1.0, alternative_supplier_count / 3.0)

    sc_pd = traditional_pd * (1 + 0.3 * otif_adj + 0.2 * inv_adj + 0.15 * network_adj)
    return sc_pd


def working_capital_velocity_index(
    inventory_velocity_z: np.ndarray, receivables_velocity_z: np.ndarray,
    payables_velocity_z: np.ndarray,
) -> np.ndarray:
    """Fusion Feature 2 - WCVI (Section A5.4)."""
    return (np.asarray(inventory_velocity_z) + np.asarray(receivables_velocity_z)
            - np.asarray(payables_velocity_z)) / 3.0


def trade_route_financial_stress_index(
    port_congestion_index: np.ndarray, freight_rate_volatility: np.ndarray,
    lc_rejection_rate: np.ndarray, payment_delay_index: np.ndarray,
    weights: tuple[float, float, float, float] = (0.35, 0.25, 0.25, 0.15),
) -> np.ndarray:
    """Fusion Feature 3 - TRFSI (Section A5.4). Weights learned from historical
    data in production; defaults here reflect the relative importance implied
    by the brief's discussion (congestion and freight volatility dominate)."""
    w1, w2, w3, w4 = weights
    return (w1 * np.asarray(port_congestion_index) + w2 * np.asarray(freight_rate_volatility)
            + w3 * np.asarray(lc_rejection_rate) + w4 * np.asarray(payment_delay_index))


def cash_conversion_cycle(dio: float, dso: float, dpo: float) -> float:
    """CCC = DIO + DSO - DPO (Section A2.2)."""
    return dio + dso - dpo


if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
    from src.data.synthetic_generator import SupplyChainDataGenerator

    gen = SupplyChainDataGenerator()
    nodes, _ = gen.generate_graph()
    lc = gen.generate_trade_finance_transactions(n=500, nodes=nodes)
    feats = build_lc_transaction_features(lc)
    print(feats[LC_TRANSACTION_FEATURE_COLUMNS].describe().T[["mean", "std"]])

    sc_pd = supply_chain_adjusted_pd(0.025, otif_actual=0.85, inv_turnover_actual=4.8,
                                      alternative_supplier_count=1)
    print("Worked example SC-PD (expect ~0.0333):", round(float(sc_pd), 4))
