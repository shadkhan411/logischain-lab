"""
Graph / entity-level feature engineering (Section A5.1).

Takes the raw `nodes` DataFrame produced by SupplyChainDataGenerator (which
already carries the computed centrality metrics) and assembles the curated,
documented feature matrix that is fed to the GNN and the XGBoost baseline.
"""
from __future__ import annotations
import pandas as pd
import numpy as np

# The 21-dimensional feature vector mirrored from Section A5.1's worked example
# (financial -> operational -> network -> geographic, in that order).
ENTITY_FEATURE_COLUMNS = [
    # financial (5)
    "current_ratio", "debt_to_equity", "ebitda_margin", "interest_coverage",
    "working_capital_ratio",
    # operational (7)
    "otif_rate", "lead_time_mean", "lead_time_std", "inventory_turnover",
    "supplier_concentration_hhi", "customer_concentration_hhi", "ccc_days",
    # network topology (5)
    "in_degree", "out_degree", "betweenness_centrality", "clustering_coefficient",
    "pagerank",
    # geographic / risk (4)
    "country_risk_score", "natural_disaster_exposure", "geopolitical_risk_score",
    "freight_cost_ratio",
]


def build_entity_features(nodes: pd.DataFrame) -> pd.DataFrame:
    """Assemble the curated entity feature matrix (Section A5.1)."""
    df = nodes.copy()
    df["working_capital_ratio"] = (
        (df["current_ratio"] - 1.0) * df["revenue"] / df["revenue"].clip(lower=1)
    )  # net working capital / revenue proxy, consistent with worked example scale
    df["working_capital_ratio"] = np.clip(df["current_ratio"] * 0.05, -0.2, 0.5)

    missing = [c for c in ENTITY_FEATURE_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing expected columns: {missing}")

    features = df[["node_id", "node_type"] + ENTITY_FEATURE_COLUMNS].copy()
    return features


def normalise_features(features: pd.DataFrame, cols=None) -> tuple[pd.DataFrame, dict]:
    """Z-score normalise numeric feature columns; returns (df, stats) for reuse at inference."""
    cols = cols or ENTITY_FEATURE_COLUMNS
    out = features.copy()
    stats = {}
    for c in cols:
        mu, sd = out[c].mean(), out[c].std() + 1e-8
        stats[c] = (mu, sd)
        out[c] = (out[c] - mu) / sd
    return out, stats


if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
    from src.data.synthetic_generator import SupplyChainDataGenerator

    gen = SupplyChainDataGenerator()
    nodes, _ = gen.generate_graph()
    feats = build_entity_features(nodes)
    print(feats.shape)
    print(feats.head())
