"""
Level-1 stacking meta-learner - Section A7.2.

A thin, reusable wrapper: fit a LightGBM meta-learner on concatenated
Level-0 base-learner outputs (GNN embeddings, TCN forecasts, Transformer
risk scores, XGBoost tabular scores, survival hazards) to produce the final
risk classification. Falls back to sklearn's HistGradientBoostingClassifier
if LightGBM is unavailable in the runtime environment.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.metrics import roc_auc_score, brier_score_loss


def fit_stacking_meta_learner(X: pd.DataFrame, y: np.ndarray, seed: int = 42, n_splits: int = 5):
    """5-fold cross-validated Level-0 predictions feed the Level-1 meta-learner
    (Section A7.2), avoiding the leakage of a base learner "grading its own homework"."""
    try:
        import lightgbm as lgb
        use_lgb = True
    except ImportError:  # pragma: no cover
        from sklearn.ensemble import HistGradientBoostingClassifier
        use_lgb = False

    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=seed, stratify=y)

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    oof_pred = np.zeros(len(Xtr))
    for fold, (tr_idx, val_idx) in enumerate(skf.split(Xtr, ytr)):
        X_fold_tr, X_fold_val = Xtr.iloc[tr_idx], Xtr.iloc[val_idx]
        y_fold_tr = ytr[tr_idx] if isinstance(ytr, np.ndarray) else ytr.iloc[tr_idx]
        if use_lgb:
            m = lgb.LGBMClassifier(n_estimators=200, max_depth=4, learning_rate=0.05,
                                    num_leaves=15, subsample=0.85, colsample_bytree=0.8,
                                    reg_lambda=1.0, random_state=seed, verbosity=-1)
        else:
            m = HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05,
                                                max_iter=200, random_state=seed)
        m.fit(X_fold_tr, y_fold_tr)
        oof_pred[val_idx] = m.predict_proba(X_fold_val)[:, 1]

    # final model trained on all of Xtr
    if use_lgb:
        final_model = lgb.LGBMClassifier(n_estimators=200, max_depth=4, learning_rate=0.05,
                                          num_leaves=15, subsample=0.85, colsample_bytree=0.8,
                                          reg_lambda=1.0, random_state=seed, verbosity=-1)
    else:
        from sklearn.ensemble import HistGradientBoostingClassifier
        final_model = HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05,
                                                       max_iter=200, random_state=seed)
    final_model.fit(Xtr, ytr)

    p_test = final_model.predict_proba(Xte)[:, 1]
    metrics = dict(
        oof_auc=float(roc_auc_score(ytr, oof_pred)),
        test_auc=float(roc_auc_score(yte, p_test)),
        test_gini=float(2 * roc_auc_score(yte, p_test) - 1),
        test_brier=float(brier_score_loss(yte, p_test)),
        backend="lightgbm" if use_lgb else "sklearn_hgb",
    )
    return final_model, (Xtr, Xte, ytr, yte, p_test), metrics
