"""
LogisChain Lab - Scenario Catalogue (Section B3.1).

Ten disruption scenario types, each parameterised by severity (1-5),
duration, and generating at least 3 categories of financial impact
(matching deliverable D2.4.3's requirement).
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np


@dataclass
class ScenarioEffect:
    """A scenario's effect on the physical + financial layers for its duration."""
    name: str
    difficulty: str
    duration_days_range: tuple[int, int]
    congestion_delta_range: tuple[float, float]
    freight_rate_multiplier_range: tuple[float, float]
    otif_delta_range: tuple[float, float]
    lc_expiry_risk: bool
    working_capital_stress: bool
    insurance_claim: bool
    description: str


SCENARIO_CATALOGUE: dict[str, ScenarioEffect] = {
    "port_congestion": ScenarioEffect(
        name="Port Congestion Event", difficulty="Medium", duration_days_range=(5, 15),
        congestion_delta_range=(1.0, 2.5), freight_rate_multiplier_range=(1.1, 1.4),
        otif_delta_range=(-0.10, -0.03), lc_expiry_risk=True, working_capital_stress=True,
        insurance_claim=False,
        description="5-15 day delays at a major hub; LC expiry risk, inventory depletion, freight spike.",
    ),
    "carrier_bankruptcy": ScenarioEffect(
        name="Carrier Bankruptcy", difficulty="High", duration_days_range=(14, 45),
        congestion_delta_range=(0.5, 1.5), freight_rate_multiplier_range=(1.3, 1.8),
        otif_delta_range=(-0.25, -0.10), lc_expiry_risk=True, working_capital_stress=True,
        insurance_claim=True,
        description="Stranded cargo, forced rerouting; cargo insurance claims, SCF disruption, WC stress.",
    ),
    "geopolitical_route_closure": ScenarioEffect(
        name="Geopolitical Trade Route Closure", difficulty="Very High", duration_days_range=(20, 90),
        congestion_delta_range=(0.3, 1.0), freight_rate_multiplier_range=(1.5, 2.8),
        otif_delta_range=(-0.30, -0.15), lc_expiry_risk=True, working_capital_stress=True,
        insurance_claim=True,
        description="Complete lane shutdown; massive freight increase, +20d lead time, insurance repricing.",
    ),
    "supplier_quality_failure": ScenarioEffect(
        name="Supplier Quality Failure", difficulty="Medium", duration_days_range=(7, 30),
        congestion_delta_range=(0.0, 0.2), freight_rate_multiplier_range=(1.0, 1.05),
        otif_delta_range=(-0.35, -0.15), lc_expiry_risk=True, working_capital_stress=True,
        insurance_claim=False,
        description="Product recalls, production halt; trade finance default, warranty claims.",
    ),
    "demand_whiplash": ScenarioEffect(
        name="Demand Whiplash (Bullwhip)", difficulty="High", duration_days_range=(10, 40),
        congestion_delta_range=(-0.5, 0.8), freight_rate_multiplier_range=(0.9, 1.3),
        otif_delta_range=(-0.15, 0.05), lc_expiry_risk=True, working_capital_stress=True,
        insurance_claim=False,
        description="Rapid +-40% demand swing; inventory obsolescence or stockout, covenant breach risk.",
    ),
    "cyber_attack": ScenarioEffect(
        name="Cyber Attack on Port/Terminal", difficulty="Very High", duration_days_range=(3, 14),
        congestion_delta_range=(1.5, 3.0), freight_rate_multiplier_range=(1.1, 1.3),
        otif_delta_range=(-0.20, -0.08), lc_expiry_risk=True, working_capital_stress=False,
        insurance_claim=True,
        description="Terminal shutdown; business interruption, container diversion, data loss.",
    ),
    "natural_disaster": ScenarioEffect(
        name="Natural Disaster (Typhoon/Flood)", difficulty="High", duration_days_range=(10, 35),
        congestion_delta_range=(1.0, 2.2), freight_rate_multiplier_range=(1.1, 1.4),
        otif_delta_range=(-0.25, -0.10), lc_expiry_risk=True, working_capital_stress=False,
        insurance_claim=True,
        description="Regional supply network disruption; CBI claims, trade finance delays.",
    ),
    "commodity_price_shock": ScenarioEffect(
        name="Commodity Price Shock", difficulty="Medium", duration_days_range=(20, 60),
        congestion_delta_range=(-0.2, 0.3), freight_rate_multiplier_range=(1.0, 1.1),
        otif_delta_range=(-0.05, 0.02), lc_expiry_risk=True, working_capital_stress=True,
        insurance_claim=False,
        description="Input cost spike +50-200%; margin compression, collateral revaluation.",
    ),
    "regulatory_sanctions_change": ScenarioEffect(
        name="Regulatory/Sanctions Change", difficulty="High", duration_days_range=(30, 365),
        congestion_delta_range=(0.2, 0.6), freight_rate_multiplier_range=(1.0, 1.15),
        otif_delta_range=(-0.10, -0.02), lc_expiry_risk=True, working_capital_stress=True,
        insurance_claim=False,
        description="Trade restrictions, compliance requirements; LC rejection, counterparty blocked.",
    ),
    "pandemic_style_disruption": ScenarioEffect(
        name="Pandemic-Style Disruption", difficulty="Extreme", duration_days_range=(90, 400),
        congestion_delta_range=(1.5, 3.5), freight_rate_multiplier_range=(1.5, 3.5),
        otif_delta_range=(-0.30, -0.15), lc_expiry_risk=True, working_capital_stress=True,
        insurance_claim=True,
        description="Multi-region, multi-sector cascading failure; systemic trade finance stress.",
    ),
}


@dataclass
class ActiveScenario:
    key: str
    effect: ScenarioEffect
    start_turn: int
    duration_turns: int
    congestion_delta: float
    freight_multiplier: float
    otif_delta: float
    affected_ports: list[str] = field(default_factory=list)

    def is_active(self, turn: int) -> bool:
        return self.start_turn <= turn < self.start_turn + self.duration_turns


def trigger_scenario(key: str, current_turn: int, all_ports: list[str], rng: np.random.Generator,
                      n_affected_ports: int = 2) -> ActiveScenario:
    effect = SCENARIO_CATALOGUE[key]
    duration_days = rng.integers(*effect.duration_days_range) if effect.duration_days_range[1] > effect.duration_days_range[0] else effect.duration_days_range[0]
    duration_turns = max(1, int(round(duration_days / 7)))
    congestion_delta = rng.uniform(*effect.congestion_delta_range)
    freight_mult = rng.uniform(*effect.freight_rate_multiplier_range)
    otif_delta = rng.uniform(*effect.otif_delta_range)
    affected = list(rng.choice(all_ports, size=min(n_affected_ports, len(all_ports)), replace=False))
    return ActiveScenario(key=key, effect=effect, start_turn=current_turn, duration_turns=duration_turns,
                           congestion_delta=congestion_delta, freight_multiplier=freight_mult,
                           otif_delta=otif_delta, affected_ports=affected)


def financial_impact_types(effect: ScenarioEffect) -> list[str]:
    """Enumerate which of the >=3 required financial impact categories this
    scenario generates (Section D2.4.3)."""
    impacts = ["port_congestion_and_freight_cost"]  # always present
    if effect.lc_expiry_risk:
        impacts.append("lc_expiry_risk")
    if effect.working_capital_stress:
        impacts.append("working_capital_stress")
    if effect.insurance_claim:
        impacts.append("insurance_claim")
    return impacts
