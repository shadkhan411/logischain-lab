"""
LogisChain Lab - Three-Layer Simulation Engine (Section B1.2).

  Physical Layer:      supply chain graph state (port congestion, freight
                        rates, per-entity OTIF), updated by triggered
                        disruption scenarios.
  Intelligence Layer:   LogisChain AI-style risk signals computed from the
                        current physical state (SC-PD, TRFSI, congestion
                        forecasts) -- reuses the exact fusion-feature formulas
                        from Section A5.4.
  Financial Layer:      trade finance / SCF portfolio state, updated each
                        turn from decisions made using (or ignoring) the
                        Intelligence Layer's signals.

1 turn = 1 simulated week (52 turns = 1 year), per Section B1.2.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass, field

from src.simulation.scenarios import SCENARIO_CATALOGUE, ActiveScenario, trigger_scenario
from src.features.financial_features import supply_chain_adjusted_pd, trade_route_financial_stress_index


@dataclass
class PhysicalState:
    port_congestion: dict  # port -> float (0-5 scale)
    freight_index: dict    # port -> float multiplier vs baseline (1.0 = normal)
    node_otif: dict        # node_id -> current OTIF (starts at baseline, degrades under scenarios)
    node_baseline_otif: dict


class LogisChainLabEngine:
    """Physical + Intelligence layer state machine. Financial layer state is
    owned by the game-mode classes (TradeFinancePortfolioMode etc.) that wrap
    this engine, since P&L bookkeeping differs per mode."""

    def __init__(self, nodes: pd.DataFrame, edges: pd.DataFrame, seed: int = 42):
        self.nodes = nodes.set_index("node_id", drop=False)
        self.edges = edges
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self.ports = nodes[nodes.node_type == "port"].node_id.tolist()
        self.turn = 0
        self.active_scenarios: list[ActiveScenario] = []
        self.scenario_log: list[dict] = []

        self.state = PhysicalState(
            port_congestion={p: 2.0 for p in self.ports},
            freight_index={p: 1.0 for p in self.ports},
            node_otif=dict(zip(nodes.node_id, nodes.otif_rate)),
            node_baseline_otif=dict(zip(nodes.node_id, nodes.otif_rate)),
        )

        # min 100 nodes / 500 transportation links (Section D2.4.1)
        n_transport_links = (edges.edge_type == "transportation").sum()
        assert len(nodes) >= 100, "Simulation graph must have >=100 nodes"
        assert n_transport_links >= 500, "Simulation graph must have >=500 transportation links"

    def step(self, trigger_prob: float = 0.12):
        """Advance one simulated week."""
        self.turn += 1

        # decay expired scenarios, revert their ports toward baseline
        still_active = []
        for sc in self.active_scenarios:
            if sc.is_active(self.turn):
                still_active.append(sc)
            else:
                for p in sc.affected_ports:
                    self.state.port_congestion[p] = max(1.0, self.state.port_congestion[p] - sc.congestion_delta)
                    self.state.freight_index[p] = max(1.0, self.state.freight_index[p] / sc.freight_multiplier)
        self.active_scenarios = still_active

        # possibly trigger a new scenario
        if self.rng.uniform() < trigger_prob:
            key = self.rng.choice(list(SCENARIO_CATALOGUE.keys()))
            sc = trigger_scenario(key, self.turn, self.ports, self.rng)
            self.active_scenarios.append(sc)
            self.scenario_log.append(dict(turn=self.turn, scenario=sc.effect.name,
                                            duration_turns=sc.duration_turns, ports=sc.affected_ports))
            for p in sc.affected_ports:
                self.state.port_congestion[p] = min(5.0, self.state.port_congestion[p] + sc.congestion_delta)
                self.state.freight_index[p] = self.state.freight_index[p] * sc.freight_multiplier
            # nodes connected to affected ports see OTIF degrade
            affected_nodes = self._nodes_connected_to_ports(sc.affected_ports)
            for nid in affected_nodes:
                base = self.state.node_baseline_otif.get(nid, 0.9)
                self.state.node_otif[nid] = float(np.clip(base + sc.otif_delta, 0.4, 0.99))

        # mild mean-reversion each turn for nodes not currently under an active scenario
        active_affected = set()
        for sc in self.active_scenarios:
            active_affected |= set(self._nodes_connected_to_ports(sc.affected_ports))
        for nid, base in self.state.node_baseline_otif.items():
            if nid not in active_affected:
                cur = self.state.node_otif[nid]
                self.state.node_otif[nid] = cur + 0.15 * (base - cur)

    def _nodes_connected_to_ports(self, ports: list[str]) -> list[str]:
        mask = self.edges.edge_type == "transportation"
        relevant = self.edges[mask & (self.edges.dst.isin(ports) | self.edges.src.isin(ports))]
        return list(set(relevant.src.tolist() + relevant.dst.tolist()) - set(ports))

    # ---- Intelligence Layer -------------------------------------------------
    def intelligence_signals(self, node_id: str) -> dict:
        """LogisChain-AI-style risk signals for a node given current physical state."""
        node = self.nodes.loc[node_id]
        otif_now = self.state.node_otif.get(node_id, node.otif_rate)
        # find nearest port(s) this node ships through for a congestion read
        connected_ports = self._connected_ports_for_node(node_id)
        congestion = float(np.mean([self.state.port_congestion[p] for p in connected_ports])) if connected_ports else 2.0
        freight_idx = float(np.mean([self.state.freight_index[p] for p in connected_ports])) if connected_ports else 1.0

        alt_supplier_proxy = float(np.clip(1.0 / max(node.supplier_concentration_hhi, 0.05), 1, 8))
        sc_pd = supply_chain_adjusted_pd(
            traditional_pd=max(node.pd_annual_true * 0.55, 0.003),  # "traditional" view underestimates
            otif_actual=otif_now, inv_turnover_actual=node.inventory_turnover,
            alternative_supplier_count=alt_supplier_proxy,
        )
        trfsi = trade_route_financial_stress_index(
            port_congestion_index=congestion / 5.0, freight_rate_volatility=min(1.0, (freight_idx - 1.0)),
            lc_rejection_rate=max(0.0, (0.90 - otif_now)), payment_delay_index=max(0.0, (0.90 - otif_now)) * 0.5,
        )
        return dict(node_id=node_id, otif_now=round(float(otif_now), 4),
                    port_congestion=round(congestion, 2), freight_index=round(freight_idx, 3),
                    sc_pd=round(float(sc_pd), 5), trfsi=round(float(trfsi), 4))

    def _connected_ports_for_node(self, node_id: str) -> list[str]:
        mask = (self.edges.edge_type == "transportation")
        rows = self.edges[mask & ((self.edges.src == node_id) | (self.edges.dst == node_id))]
        ports = set(rows.src.tolist() + rows.dst.tolist()) & set(self.ports)
        return list(ports)

    def active_scenario_summary(self) -> list[dict]:
        return [dict(name=sc.effect.name, turns_remaining=sc.start_turn + sc.duration_turns - self.turn,
                     ports=sc.affected_ports) for sc in self.active_scenarios]
