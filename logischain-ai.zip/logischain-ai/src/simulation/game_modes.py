"""
LogisChain Lab - Game Modes (Section B1.3).

Both mandatory modes (Trade Finance Portfolio Management, Supply Chain
Finance Pricing) are implemented as turn-based simulations over the shared
LogisChainLabEngine. Each mode is run twice with an identical scenario
sequence (same seed) under two decision policies:

  - "sc_aware": uses the Intelligence Layer's live signals (SC-PD, port
    congestion, TRFSI) to price/approve/reject.
  - "passive": uses only the static, book-value financial data an analyst
    would see without supply-chain integration (Section B1.1's problem
    statement) -- congestion and OTIF drift are invisible to it until a
    default actually happens.

This directly demonstrates the brief's central claim: "an AI opponent using
the LogisChain AI models... consistently outperforms learners who rely on
financial data alone" (Section B1.1).
"""
from __future__ import annotations
import numpy as np
import pandas as pd

from src.simulation.engine import LogisChainLabEngine
from src.simulation.scoring import (
    ScoreBreakdown, score_financial_performance, score_risk_management,
    score_sc_intelligence_use, score_decision_speed, score_learning_progression,
)


class TradeFinancePortfolioMode:
    """Section B1.3, Mode 1. Starting portfolio: $500M in trade finance
    facilities across corporate clients. Objective: maximise risk-adjusted
    return while keeping NPL ratio below 3%."""

    STARTING_PORTFOLIO_USD = 500e6
    NPL_THRESHOLD = 0.03
    TARGET_YIELD = 0.015

    def __init__(self, nodes: pd.DataFrame, edges: pd.DataFrame, n_clients: int = 45, seed: int = 42):
        self.nodes = nodes
        self.edges = edges
        self.seed = seed
        candidates = nodes[nodes.node_type.isin(["manufacturer", "customer"])]
        rng = np.random.default_rng(seed)
        chosen = rng.choice(candidates.node_id, size=min(n_clients, len(candidates)), replace=False)
        weights = rng.dirichlet(np.ones(len(chosen)))
        self.clients = pd.DataFrame({
            "node_id": chosen,
            "exposure_usd": weights * self.STARTING_PORTFOLIO_USD,
            "base_fee_rate": rng.uniform(0.008, 0.020, size=len(chosen)),
        })

    def run(self, policy: str, n_turns: int = 52, trigger_prob: float = 0.12) -> dict:
        assert policy in ("sc_aware", "passive")
        engine = LogisChainLabEngine(self.nodes, self.edges, seed=self.seed)  # identical scenario sequence
        rng = np.random.default_rng(self.seed + 1)

        total_fees, total_losses = 0.0, 0.0
        defaults, non_performing_usd = 0, 0.0
        decisions_using_signals, total_decisions = 0, 0
        response_turns = []
        weekly_scores = []
        flagged_before_default, actual_defaults_detected = 0, 0

        for t in range(1, n_turns + 1):
            engine.step(trigger_prob=trigger_prob)
            week_fee = 0.0
            week_loss = 0.0

            for _, client in self.clients.iterrows():
                sig = engine.intelligence_signals(client.node_id)
                total_decisions += 1

                if policy == "sc_aware":
                    decisions_using_signals += 1
                    risk_adj_spread = 1.0 + 6.0 * sig["sc_pd"] + 0.4 * sig["trfsi"]
                    monitor_trigger = sig["sc_pd"] > 0.06 or sig["port_congestion"] > 3.5
                    response_turns.append(0.3 if monitor_trigger else 1.0)  # fast reaction once signalled
                else:
                    risk_adj_spread = 1.0  # blind to live SC signals
                    response_turns.append(3.0)  # only reacts once losses show up in financials

                fee = client.exposure_usd * client.base_fee_rate / 52 * risk_adj_spread
                week_fee += fee

                # realized default probability this week, driven by the TRUE underlying risk
                # (not what either policy believes) -- this is what makes the comparison honest.
                weekly_default_prob = float(np.clip(sig["sc_pd"] / 52, 0, 0.02))
                if rng.uniform() < weekly_default_prob:
                    defaults += 1
                    loss = client.exposure_usd * 0.55  # ~55% LGD assumption
                    week_loss += loss
                    non_performing_usd += client.exposure_usd
                    if policy == "sc_aware" and (sig["sc_pd"] > 0.06 or sig["port_congestion"] > 3.5):
                        flagged_before_default += 1
                    actual_defaults_detected += 1

            total_fees += week_fee
            total_losses += week_loss
            if t % 13 == 0:  # quarterly score checkpoint
                npl_ratio = non_performing_usd / self.STARTING_PORTFOLIO_USD
                yield_so_far = (total_fees - total_losses) / self.STARTING_PORTFOLIO_USD * (52 / t)
                weekly_scores.append(score_financial_performance(
                    portfolio_yield=yield_so_far, target_yield=self.TARGET_YIELD,
                    npl_ratio=npl_ratio, npl_threshold=self.NPL_THRESHOLD,
                    risk_adjusted_return=yield_so_far,
                ))

        npl_ratio = non_performing_usd / self.STARTING_PORTFOLIO_USD
        realized_yield = (total_fees - total_losses) / self.STARTING_PORTFOLIO_USD
        early_warning_recall = (flagged_before_default / actual_defaults_detected
                                 if policy == "sc_aware" and actual_defaults_detected > 0 else
                                 (0.0 if actual_defaults_detected > 0 else 1.0))

        score = ScoreBreakdown(
            financial_performance=score_financial_performance(
                portfolio_yield=realized_yield, target_yield=self.TARGET_YIELD, npl_ratio=npl_ratio,
                npl_threshold=self.NPL_THRESHOLD, risk_adjusted_return=realized_yield),
            risk_management_quality=score_risk_management(
                concentration_ok=self.clients.exposure_usd.max() / self.STARTING_PORTFOLIO_USD < 0.10,
                max_concentration=self.clients.exposure_usd.max() / self.STARTING_PORTFOLIO_USD,
                concentration_limit=0.10, early_warning_recall=early_warning_recall,
                stress_test_pass=npl_ratio < 0.05),
            sc_intelligence_use=score_sc_intelligence_use(decisions_using_signals / max(total_decisions, 1)),
            decision_speed=score_decision_speed(float(np.mean(response_turns)) if response_turns else 3.0),
            learning_progression=score_learning_progression(weekly_scores),
        )

        return dict(
            policy=policy, total_fees_usd=total_fees, total_losses_usd=total_losses,
            realized_yield=realized_yield, npl_ratio=npl_ratio, defaults=defaults,
            scenario_log=engine.scenario_log, score=score.as_dict(),
        )


class SupplyChainFinancePricingMode:
    """Section B1.3, Mode 2. Starting programme: $200M SCF serving a supplier
    base. Objective: maximise profitability while keeping defaults below 1%
    of financed volume and participation above 80%."""

    STARTING_PROGRAMME_USD = 200e6
    DEFAULT_THRESHOLD = 0.01
    TARGET_PARTICIPATION = 0.80

    def __init__(self, nodes: pd.DataFrame, edges: pd.DataFrame, n_suppliers: int = 60, seed: int = 42):
        self.nodes = nodes
        self.edges = edges
        self.seed = seed
        candidates = nodes[nodes.node_type == "supplier"]
        rng = np.random.default_rng(seed)
        chosen = rng.choice(candidates.node_id, size=min(n_suppliers, len(candidates)), replace=False)
        weights = rng.dirichlet(np.ones(len(chosen)) * 2)
        self.suppliers = pd.DataFrame({
            "node_id": chosen, "eligible_invoice_usd": weights * self.STARTING_PROGRAMME_USD,
        })

    def run(self, policy: str, n_turns: int = 52, trigger_prob: float = 0.12) -> dict:
        assert policy in ("sc_aware", "passive")
        engine = LogisChainLabEngine(self.nodes, self.edges, seed=self.seed)
        rng = np.random.default_rng(self.seed + 2)

        total_discount_revenue, total_defaults_usd = 0.0, 0.0
        financed_volume = 0.0
        decisions_using_signals, total_decisions = 0, 0
        response_turns = []
        weekly_scores = []
        participation_events, eligible_events = 0, 0

        for t in range(1, n_turns + 1):
            engine.step(trigger_prob=trigger_prob)
            for _, s in self.suppliers.iterrows():
                sig = engine.intelligence_signals(s.node_id)
                total_decisions += 1
                eligible_events += 1

                if policy == "sc_aware":
                    decisions_using_signals += 1
                    discount_rate = 0.015 + 8.0 * sig["sc_pd"] + 0.02 * sig["trfsi"]
                    onboard = sig["sc_pd"] < 0.10  # decline the worst tail risk outright
                    response_turns.append(0.4)
                else:
                    discount_rate = 0.02  # flat rate, blind to live risk
                    onboard = True
                    response_turns.append(3.0)

                if not onboard:
                    continue
                participation_events += 1
                weekly_invoice = s.eligible_invoice_usd / 52
                financed_volume += weekly_invoice
                total_discount_revenue += weekly_invoice * discount_rate / 52

                weekly_default_prob = float(np.clip(sig["sc_pd"] / 52, 0, 0.015))
                if rng.uniform() < weekly_default_prob:
                    total_defaults_usd += weekly_invoice

            if t % 13 == 0:
                default_rate = total_defaults_usd / max(financed_volume, 1)
                participation = participation_events / max(eligible_events, 1)
                weekly_scores.append(score_financial_performance(
                    portfolio_yield=total_discount_revenue / self.STARTING_PROGRAMME_USD * (52 / t),
                    target_yield=0.01,
                    npl_ratio=default_rate, npl_threshold=self.DEFAULT_THRESHOLD,
                    risk_adjusted_return=total_discount_revenue / self.STARTING_PROGRAMME_USD * (52 / t),
                ))

        default_rate = total_defaults_usd / max(financed_volume, 1)
        participation = participation_events / max(eligible_events, 1)

        score = ScoreBreakdown(
            financial_performance=score_financial_performance(
                portfolio_yield=total_discount_revenue / self.STARTING_PROGRAMME_USD,
                target_yield=0.01, npl_ratio=default_rate, npl_threshold=self.DEFAULT_THRESHOLD,
                risk_adjusted_return=total_discount_revenue / self.STARTING_PROGRAMME_USD),
            risk_management_quality=score_risk_management(
                concentration_ok=self.suppliers.eligible_invoice_usd.max() / self.STARTING_PROGRAMME_USD < 0.10,
                max_concentration=self.suppliers.eligible_invoice_usd.max() / self.STARTING_PROGRAMME_USD,
                concentration_limit=0.10, early_warning_recall=(1.0 if policy == "sc_aware" else 0.3),
                stress_test_pass=default_rate < self.DEFAULT_THRESHOLD * 2),
            sc_intelligence_use=score_sc_intelligence_use(decisions_using_signals / max(total_decisions, 1)),
            decision_speed=score_decision_speed(float(np.mean(response_turns)) if response_turns else 3.0),
            learning_progression=score_learning_progression(weekly_scores),
        )

        return dict(
            policy=policy, total_discount_revenue_usd=total_discount_revenue,
            total_defaults_usd=total_defaults_usd, financed_volume_usd=financed_volume,
            default_rate=default_rate, participation_rate=participation,
            scenario_log=engine.scenario_log, score=score.as_dict(),
        )
