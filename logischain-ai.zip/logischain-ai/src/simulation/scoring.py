"""
LogisChain Lab - 1000-point Scoring Framework (Section B2.1).

Five weighted dimensions: Financial Performance (300), Risk Management
Quality (250), Supply Chain Intelligence Use (200), Decision Speed (100),
Learning Progression (150).
"""
from __future__ import annotations
from dataclasses import dataclass


CERTIFICATION_TIERS = [
    (0, 399, "Novice", "Bronze", "Trade finance trainee (0-6 months)"),
    (400, 599, "Practitioner", "Silver", "Junior trade finance analyst (6-18 months)"),
    (600, 749, "Specialist", "Gold", "Senior trade finance analyst (18-36 months)"),
    (750, 899, "Expert", "Platinum", "Trade finance team lead (3-5 years)"),
    (900, 1000, "Master", "Diamond", "Head of Trade Finance (5+ years)"),
]


@dataclass
class ScoreBreakdown:
    financial_performance: float  # /300
    risk_management_quality: float  # /250
    sc_intelligence_use: float  # /200
    decision_speed: float  # /100
    learning_progression: float  # /150

    @property
    def total(self) -> float:
        return (self.financial_performance + self.risk_management_quality
                + self.sc_intelligence_use + self.decision_speed + self.learning_progression)

    def certification(self) -> tuple[str, str, str]:
        t = self.total
        for lo, hi, level, badge, equiv in CERTIFICATION_TIERS:
            if lo <= t <= hi:
                return level, badge, equiv
        return "Novice", "Bronze", CERTIFICATION_TIERS[0][4]

    def as_dict(self) -> dict:
        level, badge, equiv = self.certification()
        return dict(
            financial_performance=round(self.financial_performance, 1),
            risk_management_quality=round(self.risk_management_quality, 1),
            sc_intelligence_use=round(self.sc_intelligence_use, 1),
            decision_speed=round(self.decision_speed, 1),
            learning_progression=round(self.learning_progression, 1),
            total=round(self.total, 1),
            certification_level=level, badge=badge, industry_equivalent=equiv,
        )


def score_financial_performance(portfolio_yield: float, target_yield: float, npl_ratio: float,
                                 npl_threshold: float, risk_adjusted_return: float) -> float:
    """/300. Rewards yield above target and NPL below threshold (Section B2.1 example)."""
    yield_score = min(1.0, max(0.0, portfolio_yield / max(target_yield, 1e-6))) * 150
    npl_score = min(1.0, max(0.0, 1 - npl_ratio / max(npl_threshold, 1e-6))) * 100
    rar_score = min(1.0, max(0.0, risk_adjusted_return / max(target_yield, 1e-6))) * 50
    return min(300.0, yield_score + npl_score + rar_score)


def score_risk_management(concentration_ok: bool, max_concentration: float, concentration_limit: float,
                           early_warning_recall: float, stress_test_pass: bool) -> float:
    """/250."""
    concentration_score = (100 if concentration_ok else
                            max(0, 100 * (1 - (max_concentration - concentration_limit) / concentration_limit)))
    warning_score = early_warning_recall * 100
    stress_score = 50 if stress_test_pass else 0
    return min(250.0, concentration_score + warning_score + stress_score)


def score_sc_intelligence_use(pct_decisions_using_sc_signals: float) -> float:
    """/200. Percentage of decisions that incorporated SC-derived signals (OTIF, congestion,
    SC-PD, TRFSI, etc.) rather than financial data alone."""
    return min(200.0, pct_decisions_using_sc_signals * 200)


def score_decision_speed(avg_response_turns: float, ai_opponent_response_turns: float = 0.1) -> float:
    """/100. Faster (lower-turn-count) responses to disruption alerts score higher."""
    if avg_response_turns <= ai_opponent_response_turns:
        return 100.0
    ratio = ai_opponent_response_turns / max(avg_response_turns, 1e-6)
    return max(0.0, min(100.0, ratio * 100))


def score_learning_progression(score_history: list[float]) -> float:
    """/150. Rewards a consistent upward trajectory across simulation rounds."""
    if len(score_history) < 2:
        return 75.0  # neutral baseline for a single round
    improvements = [score_history[i + 1] - score_history[i] for i in range(len(score_history) - 1)]
    positive_frac = sum(1 for d in improvements if d >= 0) / len(improvements)
    total_improvement = score_history[-1] - score_history[0]
    trend_score = max(0.0, min(1.0, 0.5 + total_improvement / 400)) * 100
    consistency_score = positive_frac * 50
    return min(150.0, trend_score + consistency_score)
