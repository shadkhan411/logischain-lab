# LogisChain AI — Feature Catalog

Every feature used anywhere in the pipeline, grouped by category, with its
computation, source, and financial/operational rationale. This satisfies
deliverable D2.1.3 (minimum 50 features across supply chain, financial, and
cross-domain categories). **65 named features** are documented below.

Data source column uses the brief's real-world source names (Section A4) even
though this build's runnable pipeline uses the synthetic generator described
in `docs/architecture.md` — the *computation* is identical either way.

## 1. Entity-level graph features (21) — `src/features/graph_features.py`

Fed to the GNN (as raw node features) and the XGBoost/credit-risk models.

| # | Feature | Formula / Source | Range | Financial rationale |
|---|---|---|---|---|
| 1 | `current_ratio` | Current Assets / Current Liabilities (financial statements / Bloomberg) | 0.4–4.0 | Liquidity buffer; low ratio raises PD |
| 2 | `debt_to_equity` | Total Debt / Total Equity | 0.05–5.0 | Leverage; primary Cox PH covariate |
| 3 | `ebitda_margin` | EBITDA / Revenue | -0.1–0.4 | Profitability cushion against shocks |
| 4 | `interest_coverage` | EBIT / Interest Expense | 0.2–25 | Debt-service capacity |
| 5 | `working_capital_ratio` | Net Working Capital / Revenue (proxy) | -0.2–0.5 | Buffer for operating cycle stress |
| 6 | `otif_rate` | On-Time-In-Full % (ERP/TMS) | 0.45–0.995 | Strongest leading indicator of distress (Section A1.3) |
| 7 | `lead_time_mean` | Mean shipment lead time, days (AIS) | 2–60 | Baseline logistics performance |
| 8 | `lead_time_std` (σ_LT) | Std. dev. of lead time (AIS) | 0.3–20 | Drives safety-stock / DIO requirement |
| 9 | `inventory_turnover` | COGS / Avg. Inventory (ERP) | 1–20 | Working-capital efficiency; covenant input |
| 10 | `supplier_concentration_hhi` | Σ(supplier_share²) (customs/ERP) | 0.05–1.0 | Counterparty concentration risk |
| 11 | `customer_concentration_hhi` | Σ(customer_share²) | 0.05–1.0 | Revenue concentration risk |
| 12 | `ccc_days` | DIO + DSO − DPO (Section A2.2) | 5–300 | Single most important WC-lending metric |
| 13 | `in_degree` | # incoming graph edges (NetworkX) | 0–20 | Supply-side diversification |
| 14 | `out_degree` | # outgoing graph edges (NetworkX) | 0–15 | Demand-side diversification |
| 15 | `betweenness_centrality` | NetworkX betweenness (approx., k=80) | 0–1 | Systemic / cascading-failure exposure |
| 16 | `clustering_coefficient` | NetworkX clustering | 0–1 | Local network redundancy |
| 17 | `pagerank` | NetworkX PageRank, α=0.85 | 0–1 | Importance-weighted network centrality |
| 18 | `country_risk_score` | World Bank Doing Business composite | 0–100 | Sovereign/operating-environment risk |
| 19 | `natural_disaster_exposure` | Regional hazard index | 0–1 | Physical disruption probability |
| 20 | `geopolitical_risk_score` | Trade-corridor risk index | 0–1 | Route-closure / sanctions exposure |
| 21 | `freight_cost_ratio` | Freight spend / Revenue | 0.02–0.35 | Margin sensitivity to freight shocks |

## 2. Temporal features (37) — `src/features/temporal_features.py`

Fed to the TCN for port-throughput / freight-rate forecasting (Section A5.2).

| Group | Features | Count | Rationale |
|---|---|---|---|
| Rolling mean | `roll_mean_{7,14,30,90}` | 4 | Smoothed trend at multiple horizons |
| Rolling std | `roll_std_{7,14,30,90}` | 4 | Volatility regime detection |
| Rolling min/max | `roll_{min,max}_{7,30}` | 4 | Tail-range awareness |
| EWMA | `ewma_{7,14,30}` | 3 | Recency-weighted trend |
| Day-of-week | `dow_0`…`dow_6` (one-hot) | 7 | Weekly seasonality |
| Month cyclical | `month_sin`, `month_cos` | 2 | Annual seasonality (smooth encoding) |
| Calendar effects | `cny_effect`, `golden_week_effect` | 2 | Known China trade-calendar shocks |
| YoY change | `yoy_pct_change` | 1 | Structural growth/decline signal |
| Lag features | `lag_{1,7,14,30}` | 4 | Autoregressive signal, same day last wk/mo |
| Fourier terms | sin/cos × {365.25, 182.625, 91.3125} days | 6 | Annual seasonality (Section A5.2 spec) |
| **Total** | | **37** | |

## 3. Trade finance transaction features (15) — `src/features/financial_features.py`

Fed to the trade-finance default stacking ensemble (Section A5.3).

| # | Feature | Source | Rationale |
|---|---|---|---|
| 1 | `lc_amount_log` | Log($ LC face value) | Stabilises heavy-tailed exposure sizes |
| 2 | `tenor_days` | LC tenor | Longer tenor = longer risk window |
| 3 | `commodity_risk_num` | Commodity risk category (0/1/2) | HS-chapter-level risk tiering |
| 4 | `trade_route_risk_score` | Historical rejection rate by lane | Route-specific base risk |
| 5 | `applicant_leverage` | Applicant debt/equity | Importer credit strength |
| 6 | `applicant_current_ratio` | Applicant liquidity | Importer payment capacity |
| 7 | `beneficiary_otif_rate` | Exporter OTIF (LogisChain supply-chain DB) | Documentary-compliance proxy |
| 8 | `historical_discrepancy_rate_applicant` | % past LCs w/ doc discrepancy | LC rejection risk |
| 9 | `historical_discrepancy_rate_beneficiary` | Same, beneficiary side | LC rejection risk |
| 10 | `port_congestion_origin` | AIS / port authority | Shipment delay risk |
| 11 | `port_congestion_destination` | AIS / port authority | LC-expiry timing risk |
| 12 | `freight_rate_percentile` | SCFI / Freightos percentile | Cost-shock exposure |
| 13 | `seasonal_factor` | Calendar-based multiplier | Pre-holiday congestion risk |
| 14 | `country_risk_differential` | Importer − exporter country risk | Cross-border risk asymmetry |
| 15 | `currency_volatility_30d` | 30-day FX vol | Settlement risk |

## 4. Cross-domain fusion features (3) — `src/features/financial_features.py`

The brief's headline innovation (Section A5.4), implemented as exact closed-form formulas.

| Feature | Formula | Verified against brief |
|---|---|---|
| **SC-PD** (Supply-Chain-Adjusted PD) | `PD_trad × (1 + 0.3·OTIF_adj + 0.2·Inv_adj + 0.15·Network_adj)` | ✅ Reproduces worked example exactly: 2.5% → 3.33% |
| **WCVI** (Working Capital Velocity Index) | `(InvVelocity_z + ReceivablesVelocity_z − PayablesVelocity_z) / 3` | Implemented as specified |
| **TRFSI** (Trade Route Financial Stress Index) | `w1·PortCongestion + w2·FreightVol + w3·LCRejection + w4·PaymentDelay` | Implemented as specified |

## 5. Shipment event-token features (7 per event × 8 events) — `src/models/transformer.py`

Fed to the Transformer shipment-risk model (Section A3.3).

| Feature | Description |
|---|---|
| `event_type` (one-hot, 8 dims) | Which lifecycle stage (booking → delivery) |
| `position` | Normalised sequence position (0–1) |
| `origin_congestion_index` | Weighted by relevance to early-lifecycle events |
| `destination_congestion_index` | Weighted by relevance to late-lifecycle events |
| `vessel_speed_ratio` | Actual vs. planned speed (route-adherence signal) |
| `carrier_reliability_score` | Historical on-time performance |
| `weather_risk_score` | Elevated during transit-phase events |
| `cargo_value_log` | Log cargo value (damage-severity context) |

## 6. Working capital shock features (6) — `src/financial/ccc_predictor.py`

| Feature | Rationale |
|---|---|
| `horizon_days` | 30/60/90-day prediction horizon |
| `delta_otif` | OTIF change → drives ΔDIO |
| `delta_lead_time_std` | Lead-time variance change → drives ΔDIO |
| `delta_freight_cost_ratio` | Freight cost change → drives ΔDPO |
| `delta_port_congestion` | Congestion change → drives ΔDSO |
| `delta_inventory_turnover` | Turnover change → drives ΔDIO |

## 7. Stacking-ensemble Level-0 outputs (9) — `src/financial/trade_finance_default.py`

Base-learner outputs concatenated for the Level-1 meta-learner (Section A7.2).

| Feature | Source model |
|---|---|
| `applicant_xgb_pd` | XGBoost supplier-default model |
| `applicant_cox_hazard` | Cox PH survival model |
| `beneficiary_xgb_pd` | XGBoost supplier-default model |
| `applicant_emb_mean`, `applicant_emb_norm` | GNN entity embedding (128-dim, summarised) |
| `beneficiary_emb_mean`, `beneficiary_emb_norm` | GNN entity embedding (128-dim, summarised) |
| `transformer_delay_prob` | Shipment-risk Transformer |
| `transformer_risk_score` | Shipment-risk Transformer |

---

**Total: 21 + 37 + 15 + 3 + 8 + 6 + 9 = 99 individually named feature columns**
(the deliverable's 50-feature minimum is exceeded across all three required
categories: supply chain, financial, and cross-domain).
